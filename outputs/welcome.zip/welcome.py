def hello(event, context):
	print("this was deployed using terraform by Cathal Aherne")
